####  Modifying the Contenets  #####

Go to Folder "chapters"

--> Locate the file with Name "edit_file.txt" and Modify the content as per your wish

--> Locate the files with "chapter#.txt" and Modify the content as per your wish

--> Locate the files with "references.txt" and Modify the content as per your wish


##### Run the Report #####

Go to project File

--> Find the file with Name "Report_Main.tex"

--> Run this file using TExStudio

This will generate pdf File with the same name


